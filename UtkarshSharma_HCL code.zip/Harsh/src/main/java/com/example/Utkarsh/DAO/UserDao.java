package com.example.Utkarsh.DAO;

import java.util.List;

import com.example.Utkarsh.Entity.Users;

public interface UserDao {
		
	public List<Users> getAll(String SSN);
}
