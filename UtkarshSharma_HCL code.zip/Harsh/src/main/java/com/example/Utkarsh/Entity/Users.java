package com.example.Utkarsh.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employeeDetails")
public class Users {
    
	@Id
	@Column(name="SSN")
	private String userId;
	@Column(name="Loan_Amt")
	private int loan_amt;
	@Column(name="Current_AnualIncome")
	private int anuIcome;
	@Column(name="Loan_Date")
	private int loanDate;
	
	
	public Users()
	{
		
	}


	public Users(String userId, int loan_amt, int anuIcome, int loanDate) {
		super();
		this.userId = userId;
		this.loan_amt = loan_amt;
		this.anuIcome = anuIcome;
		this.loanDate = loanDate;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public int getLoan_amt() {
		return loan_amt;
	}


	public void setLoan_amt(int loan_amt) {
		this.loan_amt = loan_amt;
	}


	public int getAnuIcome() {
		return anuIcome;
	}


	public void setAnuIcome(int anuIcome) {
		this.anuIcome = anuIcome;
	}


	public int getLoanDate() {
		return loanDate;
	}


	public void setLoanDate(int loanDate) {
		this.loanDate = loanDate;
	}


	@Override
	public String toString() {
		return "Users [userId=" + userId + ", loan_amt=" + loan_amt + ", anuIcome=" + anuIcome + ", loanDate="
				+ loanDate + "]";
	}
		
}
