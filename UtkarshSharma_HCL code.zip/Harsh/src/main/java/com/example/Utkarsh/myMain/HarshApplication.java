package com.example.Utkarsh.myMain;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HarshApplication {

	public static void main(String[] args) {
		SpringApplication.run(HarshApplication.class, args);
	}

}
