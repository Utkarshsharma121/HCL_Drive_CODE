package com.example.Utkarsh.DAOImpl;

import java.util.List;

import javax.persistence.EntityManager;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.Utkarsh.DAO.UserDao;
import com.example.Utkarsh.Entity.Users;

@Repository
@Component
public class DAOService implements UserDao {

	private EntityManager entityManager;
	
	@Autowired
	public DAOService(EntityManager theEntityManager)
	{
	 entityManager = theEntityManager;
	}
	
	@Override
	public List<Users> getAll(String SSN) {
		// TODO Auto-generated method stub
	 
		Session currentSession = entityManager.unwrap(Session.class);		
		Query<Users> createQuery = currentSession.createQuery("from employeeDetails where SSN =: ssnNumber",Users.class);
		createQuery.setParameter("ssnNumber",SSN);
		List<Users> users = createQuery.getResultList();
		return users;
	}
	
}
