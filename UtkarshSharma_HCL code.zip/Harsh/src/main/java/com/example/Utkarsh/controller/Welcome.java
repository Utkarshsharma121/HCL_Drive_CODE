package com.example.Utkarsh.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Utkarsh.DAOImpl.DAOService;
import com.example.Utkarsh.Entity.Users;

@RestController
public class Welcome {

	private DAOService daoservice;
	
	@Autowired
	public Welcome(DAOService thedaoservice)
	{
		daoservice = thedaoservice;
	}
	
	@GetMapping("/creditScoreHistory/{SSN}")
	public List getUSerById(@PathVariable String ssnNumber) throws CustomException
	{
		List<Users> list = new ArrayList<>();
		list = daoservice.getAll(ssnNumber);
		if(list.size()>0)
			return list;
		else
			throw new CustomException("No user found");
	}
	@ExceptionHandler
	public ResponseEntity<CustomMessage> handleException(CustomException cus)
	{
		CustomMessage custom = new CustomMessage(404,"No user record found");
		return new ResponseEntity<>(custom,HttpStatus.NOT_FOUND);
		
	}

	}



