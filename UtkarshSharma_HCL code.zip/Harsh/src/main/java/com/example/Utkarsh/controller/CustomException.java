package com.example.Utkarsh.controller;

public class CustomException extends Exception {
	
	CustomException(String msg)
	{
		super(msg);
	}

}
